package com.wipro.automobile.ship;

public class compartment {
	
	private int height;
	private int width;
	private int breadth;
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getBreadth() {
		return breadth;
	}
	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}
public static void main(String args[])
{
	compartment o = new compartment();
	o.setHeight(5);
	System.out.println("Height="+o.getHeight());
	o.setWidth(12);
	System.out.println("Width="+o.getWidth());
    o.setBreadth(32);
    System.out.println("Breadth="+o.getBreadth());
}
}
