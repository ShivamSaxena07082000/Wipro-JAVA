package com.automobile.FourWheeler;

import java.util.Scanner;

import com.automobile.FourWheeler.*;

public class Test extends Ford {

	public static void main(String[] args) {
		
		String mod,num,own;
		int Sp,gp;
	    Test hn =new Test();
        Scanner sc = new Scanner(System.in);
        mod=sc.nextLine();
        System.out.println("Model Name="+hn.getModelName(mod));
        num= sc.nextLine();
        System.out.println("Registration Number="+hn.getRegistrationNumber(num));
        own = sc.nextLine();
        System.out.println("Owner Name="+hn.getOwnerName(own));
        Sp = sc.nextInt();
        System.out.println("Speed="+hn.Speed(Sp));
        gp = sc.nextInt();
        System.out.println("Speed="+hn.gps(gp));
        hn.tempControl();

	}

}
