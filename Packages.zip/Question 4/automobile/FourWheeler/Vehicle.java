package com.automobile.FourWheeler;

public abstract class Vehicle {

	 public abstract String getModelName();
	 public abstract String getRegistrationNumber();
	 public abstract String getOwnerName();
	 public abstract int speed();
	 public abstract int gps();
}
class Ford 
{
	public String getModelName(String model)
	{
		return model;
	}
	public String getRegistrationNumber(String number)
	{
		return number;
	}
	public String getOwnerName(String owner)
	{
		return owner;
	}
	public  int Speed(int speed)
	{
		return speed;
	}
	public int gps(int Gps)
	{
		return Gps;
	}
	public void tempControl()
	{
		System.out.println("provide facility to control the air conditioning device which is available in the car");
	}
}
