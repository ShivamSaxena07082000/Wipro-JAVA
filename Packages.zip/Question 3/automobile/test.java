package com.automobile;
import com.automobile.*;
import java.util.Scanner;

public class test {

	public static void main(String[] args) {
		
		String mod,num,own;
		int Speed;
		Honda hn =new Honda();
        Scanner sc = new Scanner(System.in);
        mod=sc.nextLine();
        System.out.println("Model Name="+hn.getModelName(mod));
        num= sc.nextLine();
        System.out.println("Registration Number="+hn.getRegistrationNumber(num));
        own = sc.nextLine();
        System.out.println("Owner Name="+hn.getOwnerName(own));
        Speed = sc.nextInt();
        System.out.println("Speed="+hn.getSpeed(Speed));
        hn.radio();
        hn.cdplayer();

	}

}
