package com.automobile;
import java.util.*;
public abstract class vehicle {
	 
	 public abstract String getModelName();
	 public abstract String getRegistrationNumber();
	 public abstract String getOwnerName();

}
class Hero 
{
	public String getModelName(String model)
	{
		return model;
		
	}
	public String getRegistrationNumber(String number)
	{
		return number;
	}
	public String getOwnerName(String owner)
	{
		return owner;
	}
	public  int getSpeed(int speed)
	{
		return speed;
	}
	public void radio()
	{
		System.out.println("Provide facility to control the device");
	}
}
class Honda extends Hero
{
	public  int getSpeed(int speed)
	{
		return speed;
	}
	public void cdplayer()
	{
		System.out.println("Provide facility to control the cdplayer");
	}
}
