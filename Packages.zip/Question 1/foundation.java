package test;

public class foundation {
	
	private int var1=8;
	public void setvar1(int var1)
	{
		this.var1 =var1;
	}
	public int getvar1()
	{
		return this.var1;
	}
	int var2=9;
	protected int var3=10;
	public int var4=11;
	

}
