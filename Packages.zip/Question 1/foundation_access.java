package test;
import test.foundation.*;
public class foundation_access extends foundation {
	
	public static void main(String args[])
	{
		foundation_access ob = new foundation_access();
		System.out.println(ob.getvar1());
		System.out.println(ob.var2);
		System.out.println(ob.var3);
		System.out.println(ob.var4);
	}

}
