import java.util.*;
public class Question2_Numbers_Conversion {

	public static void main(String[] args) {
		
		int num,r,num1,num2;
		String binary="",octal="",hexadecimal="" ;
		Scanner sc = new Scanner(System.in);
		System.out.print("Given number:");
		num=sc.nextInt();
		num1=num;
		num2=num;
		while(num>0)
		{
			r=num%2;
			binary =r+binary;
			num=num/2;
		}
		System.out.println("Binary Equivalent:"+binary);
		while(num1>0)
		{
			r=num1%8;
			octal =r+octal;
			num1=num1/8;
		}
		System.out.println("Octal Equivalent:"+octal);
		while(num2>0)
		{
			r=num2%16;
			hexadecimal =r+hexadecimal;
			num2=num2/16;
		}
		System.out.println("Hexadecimal Equivalent:"+hexadecimal);
		
		
		
	}

}
