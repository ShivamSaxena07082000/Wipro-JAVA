import java.util.*;
public class Question3_Numbers {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the integer number (1 to 255) :");
		int Num = sc.nextInt();
		
		String op = String.format("%8s", Integer.toBinaryString(Num)).replace(' ', '0');
		System.out.println(op);
		

	}

}
