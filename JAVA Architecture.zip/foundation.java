package test;

public class foundation {
	
	private int var1=8;
	int var2=9;
	protected int var3=10;
	public int var4=11;
	

}
