
public abstract  class compartment {
    
	public abstract String notice();
}
class FirstClass
  {
	public String notice(String Notice)
	{
		return Notice;
	}
  }

class Ladies extends FirstClass
  { 
	@Override
	public String notice(String Notice)
	{
		return Notice;
	}
  }  
class General extends Ladies
  { 
	@Override
	public String notice(String Notice)
	{
		return Notice;
	}
  }
class Luggage extends General
  { 
	@Override
	public String notice(String Notice)
	{
		return Notice;
	}
  }
 
