import java.lang.Math.*;
public class TestCompartment extends Luggage {

	public static void main(String[] args) {
		
     int comp[]= new int[10];
     TestCompartment ob = new TestCompartment();
     int min=1,max=4,number;
     number = (int)Math.floor(Math.random()*(max-min+1)+min);
     switch(number)
     {
     case 1: 
    	    System.out.println(ob.notice("Luggage"));
    	    break;
     case 2:
    	    System.out.println(ob.notice("Ladies"));
 	        break;
     case 3:
    	    System.out.println(ob.notice("General"));
	        break;
     case 4:
    	    System.out.println(ob.notice("FirstClass"));
	        break;
     }
	}

}
