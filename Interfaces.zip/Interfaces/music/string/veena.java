package music.string;
import music.*;

public class veena implements Playable {
	
	public void Play()
	{
		System.out.println("Veena Method called");
	}

}
