package music.wind;
import music.*;
public class Saxophone implements Playable {

	public void Play()
	{
		System.out.println("Saxophone class");
	}
}
