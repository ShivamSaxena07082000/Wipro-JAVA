package live;
import  music.string.*;
import music.wind.*;

public class Test {

	public static void main(String[] args) {
		
		veena ob = new veena();
		ob.Play();
		Saxophone o = new Saxophone();
		o.Play();
		
		

	}

}
