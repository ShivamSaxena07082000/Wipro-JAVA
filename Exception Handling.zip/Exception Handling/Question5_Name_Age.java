import java.util.*;
import java.io.*;
class UnderAgeException extends Exception {
	
	UnderAgeException()
	{
		super("Age is not correct");
	}	
}
class Question5_Name_Age
{
	public static void main(String[] args){
		
		String name;
		int age;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a name");
		name = sc.nextLine();
		System.out.println("Enter age");
		age = sc.nextInt();
		try
		{
		if(age>=18 && age<60)
		{
			System.out.println("Age is correct");
		}
		else
		{
			throw new UnderAgeException();
		}
		}
		catch(UnderAgeException e)
		{
		   e.printStackTrace();
		}

	}

}
