import java.util.*;
public class Question2_mathOperation {

	public static void main(String[] args) {
		
		int a[] = new int[6];
		int i,sum=0,avg;
		try
		{
		for(i=0;i<5;i++)
		{
		a[i]=Integer.parseInt(args[i]);
		}
		}
		catch(NumberFormatException no)
		{
			System.out.println("Array elements must be an Integer");
		}
		try
		{
		for(i=0;i<5;i++)
		{
			sum=sum+a[i];
		}
		avg=sum/5;
		System.out.println("Sum="+sum);
		System.out.println("Average="+avg);
		}
		catch(ArithmeticException e)
		{
			System.out.println("Division by zero is not allowed");
		}
	}

}
