import java.util.*;
public class Question3 {

	public static void main(String[] args) {
		
		int stu1[] = new int[6];
		int stu2[] = new int[6];
		int n,i,sum=0,avg;
		String student1,student2;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter name of first Student");
		student1 = sc.nextLine();
		System.out.println("Enter name of second Student");
		student2 = sc.nextLine();
		System.out.println("Enter marks of first Student");
		try
		{
		for(i=0;i<3;i++)
		{
			stu1[i]=sc.nextInt();
		}
		System.out.println("Enter marks of second Student");
		for(i=0;i<3;i++)
		{
			stu2[i]=sc.nextInt();
		}
		
		for(i=0;i<3;i++)
		{
			sum=sum+stu1[i]+stu2[i];
		}
		avg=sum/2;
		System.out.println("Average="+avg);
	    }
	    catch(InputMismatchException e)
	    {
		System.out.println("Array elements are only integer values");
     	}

	}

}
