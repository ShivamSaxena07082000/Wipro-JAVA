import java.util.*;
class InvalidCountryException extends Exception {

	InvalidCountryException()
	{
		super("User outside India cannot be registered");
	}
}
class UserRegistration
{
	void registerUser(String userName,String countryName)
	{
		try
		{
		if(countryName.equals("India"))
		{
			System.out.println(userName+"User registration done successfully"+countryName);
		}
		else
		{
			throw new InvalidCountryException();
		}
		}
		catch(InvalidCountryException e)
		{
			e.printStackTrace();
		}
		
		
	}

	public static void main(String args[])throws InvalidCountryException
	{
		
		String country, name;
		UserRegistration ob = new UserRegistration();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your name");
		name = sc.nextLine();
		System.out.println("Enter a country");
		country = sc.nextLine();
		ob.registerUser(name,country);
	}
}
