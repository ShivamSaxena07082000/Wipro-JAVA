import java.util.*;
public class Question1_array_related {
 
	public static void main(String args[]) {
		
	
	int arr[]= new int[4];
	int n,n1;
	Scanner s =new Scanner(System.in);
	System.out.println("Enter the number of elements in an array");
	n=s.nextInt();
	System.out.println("Enter the elements in an array");
	try
	{
	for(int i=0;i<n;i++)
	{
		arr[i]=s.nextInt();
	}
	
	System.out.println("Enter the index of the array element you want to access");
	try
	{
	n1=s.nextInt();
	System.out.println("The array element at index"+" "+n1+" "+"="+" "+arr[n1]);
	}
	catch(ArrayIndexOutOfBoundsException e)
	{
	  System.out.println(e.getMessage());
	}
	}
	catch(InputMismatchException n2)
	{
		System.out.println("Element need not to be alphabet or symbol");
	}
}
}