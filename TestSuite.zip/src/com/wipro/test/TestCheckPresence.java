package com.wipro.test;
import static org.junit.Assert.*;
import org.junit.Test;
import com.wipro.task.*;
public class TestCheckPresence {
	
	@Test
	public void sortValues()
	{
		DailyTasks ob = new DailyTasks();
		int []a ={12,17,3,89,43,54,23}	;
		int []expected_out = {3,12,17,23,43,54,89};
		int []res = ob.sortValues(a);
		assertArrayEquals(expected_out,res);
		boolean b =true;
		assertTrue(b);
		System.out.println("Passed");
	}


}
