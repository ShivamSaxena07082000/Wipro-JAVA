package com.wipro.test;
import org.junit.*;
import com.wipro.task.*;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertTrue;

public class TestSort {
	@Test
	public void sortValues()
	{
		DailyTasks ob = new DailyTasks();
		int []a ={12,17,3,89,43,54,23}	;
		int []expected_out = {3,12,17,23,43,54,89};
		int []res = ob.sortValues(a);
		assertArrayEquals(expected_out,res);
		boolean b =true;
		assertTrue(b);
		System.out.println("Passed");
	}

}
