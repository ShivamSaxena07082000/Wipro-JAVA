package com.wipro.test;
import org.junit.runner.*;
import org.junit.runners.*;

@RunWith(Suite.class)
@Suite.SuiteClasses({TestSort.class,TestCheckPresence.class,TestStringConcat.class})
public class TestSuiteex {

}
