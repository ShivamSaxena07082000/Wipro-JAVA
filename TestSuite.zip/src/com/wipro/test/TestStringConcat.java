package com.wipro.test;
import com.wipro.task.DailyTasks;
import  org.junit.*;
import static org.junit.Assert.*;
public class TestStringConcat {
    @Test
	public void doStringConcat()
	{
	DailyTasks ob = new DailyTasks();
	String str1 ="Shivam";
	String str2= "Saxena";
	String expected_out = "Shivam Saxena";
	String actstr = ob.doStringConcat(str1,str2);
	assertEquals(expected_out,actstr);
	boolean b = true;
	System.out.println("Passed");
	
	
	}
	
}
